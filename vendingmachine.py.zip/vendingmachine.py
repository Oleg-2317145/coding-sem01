class VendingMachine:
    def __init__(self):
        self.items = [
            {'name': 'Coca-Cola', 'price': 1.50},
            {'name':'Fanta','price':1.00},
            {'name':'Pepsi','price':1.50},
            {'name':'Mars','price':1.50},
            {'name':'Snikers','price':1.00},
            {'name': 'Chips', 'price': 1.00},
            {'name': 'Candy', 'price': 0.75}       
        ]
        self.allowed_denominations = [0.05, 0.10, 0.20, 0.50, 1.00, 2.00, 5.00, 10.00, 20.00, 50.00]

    def display_menu(self):
        print("Welcome to the vending machine!")
        print("Available items:")
        for i, item in enumerate(self.items, 1):
            print(f"{i}. {item['name']}: £{item['price']}")

    def is_valid_denomination(self, amount):
        return amount in self.allowed_denominations

    def purchase_item(self, choice, amount):
        choice -= 1  # Adjusting index for zero-based indexing
        if choice < 0 or choice >= len(self.items):
            print("Invalid item number.")
            return

        item = self.items[choice]
        if not self.is_valid_denomination(amount):
            print("Invalid denomination. Please insert valid coins or notes.")
            return

        if amount < item['price']:
            print("Insufficient amount.")
            return

        change = amount - item['price']
        print(f"Enjoy your {item['name']}! Your change is £{change:.2f}.")

# Main program
if __name__ == "__main__":
    vending_machine = VendingMachine()
    vending_machine.display_menu()

    while True:
        try:
            choice = int(input("Enter the number of the item you want to purchase (or 0 to exit): "))
            if choice == 0:
                print("Thank you for using the vending machine!")
                break

            amount = float(input("Enter the amount you're inserting: "))
            vending_machine.purchase_item(choice, amount)
        except ValueError:
            print("Invalid input. Please enter a valid number.")
